@extends('layouts.main')

@section('title', 'PROFIL')

@section('content')
    <div class="hero" style="text-align:center; padding:90px 20px;">
    <h1>👤 Profil</h1>
    <p>Nama: Hammam Al Kamil</p>
    <p>Alamat: Jepara, Jawa Tengah</p>
    <p>Hobi: Membaca & Ngoding</p>
</div>
@endsection
