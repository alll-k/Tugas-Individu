<?php $__env->startSection('title', 'PROFIL'); ?>

<?php $__env->startSection('content'); ?>
    <div class="hero" style="text-align:center; padding:90px 20px;">
    <h1>👤 Profil</h1>
    <p>Nama: Hammam Al Kamil</p>
    <p>Alamat: Jepara, Jawa Tengah</p>
    <p>Hobi: Membaca & Ngoding</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas-Individu\resources\views/profile.blade.php ENDPATH**/ ?>