<?php $__env->startSection('title', 'TENTANG KAMI'); ?>

<?php $__env->startSection('content'); ?>
    <div class="hero" style="text-align:center; padding:90px 20px;">
    <h1>ℹ️ Tentang Kami</h1>
    <p>Kami adalah tim yang berfokus pada pengembangan teknologi web dan aplikasi modern.</p>
    <p>Misi kami adalah menghadirkan inovasi yang bermanfaat untuk masyarakat.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas-Individu\resources\views/about.blade.php ENDPATH**/ ?>